<?php
error_reporting(0);
$botToken = '7676693411:AAHTXTiRhlLUYmvlx_QosydEMMqJjH1-Gj8';
$dbUserName = 'l2FbnBRpOMbaw';
$dbPassword = 'OKG2wmf4wjQNg';
$dbName = 'wizwiz';
$botUrl = 'https://wiz.viato.ir/bot/';
$admin = 1543299428;
?>
